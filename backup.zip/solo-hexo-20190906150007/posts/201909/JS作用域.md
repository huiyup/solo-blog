title: JS作用域
date: '2019-09-05 10:31:02'
updated: '2019-09-05 10:33:09'
tags: [js]
permalink: /articles/2019/09/05/1567650662695.html
---
### 执行环境及作用域

> 代码在一个环境中执行时会创建一个作用域链，保证对执行环境的有权访问和函数的有序访问。
> 搜索的过程始终是从作用域链的前端开始，向后回溯

全局作用域

```js
var color = "blue";
function changeColor(){
    if (color === "blue"){
        color = "red";
    } else {
        color = "blue";
    }
}
changeColor();
alter("Color is now"+color);
```

局部作用域

```js
var color = "blue";
function changeColor(){
    var anotherColor = "red";
    function swapColors(){
        var tempColor = anotherColor;
        anotherColor = color;
        color = tempColor;
        //这里可以访问color、anotherColor和tempColor
    }
    //这里可以访问color和anotherColor,但不能访问tempColor
    swapColor()
}
//这里只能访问color
changeColor();
```

块级作用域

```js
if(1){
    let a = 10;
    var b =11;
}
console.log(a);
console.log(b);
```
